# rv32i-sim
Simple Simulator for RV32I
