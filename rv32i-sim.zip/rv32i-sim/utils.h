#ifndef UTILS_H
#define UTILS_H

uint32_t get_bits(uint32_t t, int s, int e);
#endif
